# Cabe no Bolso - Planejador de Despesas Compartilhadas

Aplicação desenvolvida em Java com interface gráfica Swing para planejamento e rateio de despesas compartilhadas, aplicando o padrão de arquitetura MVC e Orientação a Objetos.

---

## 👥 Equipe de Desenvolvimento

- **Pedro Atila Freitas Costa** — Matrícula: 2640880
- **Carlos Alberto Holanda da Cruz Neto** — Matrícula: 2641734
- **Elvis Júnior Barros de Oliveira** — Matrícula: 2640898
- **Igor Farias Valentim** — Matrícula: 2640869
- **Naebia Costa de Oliveira** — Matrícula: 2640866
- **Jose Aedo Ferreira Freire** — Matrícula: 2640883

---

## 🛠️ Tecnologias e Arquitetura

- **Linguagem**: Java (JDK 17 ou superior)
- **Dependências externas**: nenhuma (apenas a biblioteca padrão do JDK)
- **Interface Gráfica**: Java Swing (`JFrame`, `JTabbedPane`, `JTable`, `JList`, `JPanel`)
- **Arquitetura**: Padrão MVC (`model`, `persistence`, `controller`, `view`)
- **Persistência de Dados**: Serialização de objetos Java (`.dat`)
- **Conceitos de POO Aplicados**:
  - **Abstração & Encapsulamento**: Atributos privados, validações defensivas e controle de acesso via getters e setters.
  - **Herança & Polimorfismo**: Classe abstrata `Despesa` especializada em `DespesaFixa` e `DespesaPorPessoa`, com sobrescrita polimórfica do método `calcularRateio()`.
  - **Tratamento de Exceções**: Validações de integridade contra duplicidade, exclusão de registros com dependência e entradas numéricas inválidas.

---

## 📂 Estrutura de Pacotes do Projeto

```text
cabe_no_bolso/
├── bin/                                    # Arquivos compilados (.class)
├── src/
│   ├── model/                              # Regras de negócio e entidades
│   │   ├── Despesa.java
│   │   ├── DespesaFixa.java
│   │   ├── DespesaPorPessoa.java
│   │   ├── Participante.java
│   │   └── Planejamento.java
│   ├── persistence/                        # Contrato e serialização de arquivos
│   │   ├── ArquivoPersistenciaService.java
│   │   └── PersistenciaService.java
│   ├── controller/                         # Intermediação entre visão e modelo
│   │   └── PlanejamentoController.java
│   └── view/                               # Interface gráfica Java Swing
│       ├── MainFrame.java
│       ├── PainelDespesas.java
│       ├── PainelParticipantes.java
│       └── PainelResumo.java
├── docs/
│   └── uml.png                             # Diagrama de classes UML
├── .gitignore
└── README.md
```

---

## 🧩 Diagrama de Classes

![Diagrama de classes UML](docs/uml.png)

- `Planejamento` **compõe** as despesas (1 → 0..\*) e **agrega** os participantes (1 → 0..\*).
- Cada `Despesa` **referencia** de 1 a N participantes cadastrados (os mesmos objetos), o que mantém os vínculos ao alterar dados e ao salvar/carregar.
- `PlanejamentoController` usa a interface `PersistenciaService`, implementada por `ArquivoPersistenciaService` (serialização em `.dat`).

---

## 🚀 Como Compilar e Executar

### Via Terminal

1. Clone o repositório:

   ```bash
   git clone https://github.com/Pedroviz/cabe_no_bolso.git
   cd cabe_no_bolso
   ```

2. Compile o código-fonte:

   ```bash
   javac -encoding UTF-8 -d bin -sourcepath src src/view/MainFrame.java
   ```

3. Execute a aplicação:
   ```bash
   java -cp bin view.MainFrame
   ```

---

## 🧪 Como Reproduzir o Teste do Caso de Referência (Passeio da Turma)

1. Abra a aba **Participantes** e adicione:
   - Código `1`: Ana (Orçamento: R$ 70,00)
   - Código `2`: Bruno (Orçamento: R$ 60,00)
   - Código `3`: Carla (Orçamento: R$ 70,00)

2. Abra a aba **Despesas** e cadastre:
   - **Transporte** | Valor: R$ 90,00 | Tipo: Fixa | Participantes: Ana, Bruno, Carla
   - **Almoço** | Valor: R$ 20,00 | Tipo: Por Pessoa | Participantes: Ana, Bruno, Carla
   - **Atividade Recreativa** | Valor: R$ 30,00 | Tipo: Fixa | Participantes: Ana, Carla
   - **Sobremesa** | Valor: R$ 10,00 | Tipo: Por Pessoa | Participantes: Ana, Bruno, Carla

3. Acesse a aba **Resumo**:
   - Confira o Custo Total Geral: **R$ 210,00**
   - Verifique o gasto individual:
     - **Ana**: R$ 75,00 (Excede R$ 5,00)
     - **Bruno**: R$ 60,00 (Dentro do orçamento)
     - **Carla**: R$ 75,00 (Excede R$ 5,00)

---

---

## 🧪 Testes Adicionais (seção 5 do enunciado)

Partindo do caso de referência acima (exceto no teste de centavos):

| Cenário | Como reproduzir | Resultado esperado |
|---|---|---|
| Centavos no rateio | Novo planejamento; cadastre códigos 1, 2 e 3 (orçamento 0) e uma despesa **Fixa** de `100` com os três | Resumo: 33,34 · 33,33 · 33,33; total 100,00 |
| Entrada inválida | Na aba Despesas, tente adicionar: sem marcar participantes; valor `-10`; valor vazio; descrição vazia | Mensagem de erro e lista de despesas inalterada |
| Código duplicado | Na aba Participantes, cadastre outro participante com código `1` | Mensagem “Já existe um participante com este código.” |
| Alteração de orçamento | Selecione Ana, altere o orçamento para `80` e clique em **Atualizar Nome/Orçamento** | Ana: 75,00, dentro do orçamento |
| Exclusão de despesa | Na aba Despesas, selecione **Atividade Recreativa** e clique em **Excluir Selecionada** | 60,00 por pessoa; total 180,00 |
| Salvar e reiniciar | Aba Resumo → **Salvar Arquivo** (`planejamento.dat`); feche e abra o programa; **Carregar Arquivo** | Mesmos participantes, despesas e totais, sem duplicar |
| Arquivo ausente ou inválido | **Carregar Arquivo** com um nome inexistente ou com um arquivo de texto renomeado para `.dat` | Mensagem de falha; planejamento atual mantido |
| Planejamento vazio | **Novo Planejamento Vazio** | Listas e totais zerados |
| Exclusão com vínculo | Na aba Participantes, selecione Bruno e clique em **Excluir Selecionado** | Exclusão bloqueada com mensagem |

Os resultados obtidos e as divergências encontradas estão documentados no relatório técnico (seções 4 e 5).
